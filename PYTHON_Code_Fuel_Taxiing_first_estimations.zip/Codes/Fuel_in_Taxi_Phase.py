import math

class Plane:
    def __init__(self, a2_Departure: float, b2_Departure: float, c2_Departure: float, 
                 a2_Arrival: float, b2_Arrival: float, c2_Arrival: float, design_Fuel: float):
        #Considered 0 if p-value bigger than 0.10 
        self.a2_Departure = a2_Departure 
        self.b2_Departure = b2_Departure
        self.c2_Departure = c2_Departure
        self.a2_Arrival = a2_Arrival 
        self.b2_Arrival = b2_Arrival
        self.c2_Arrival = c2_Arrival
        self.design_Fuel = design_Fuel

class Taxi:
    def __init__(self, plane: Plane, time_Departure: float, time_Arrival: float, na_Departure: int,  
                 na_Arrival: int, Tamb: float):
        self.plane = plane
        self.time_Departure = time_Departure
        self.time_Arrival = time_Arrival
        self.na_Departure = na_Departure
        self.na_Arrival = na_Arrival
        self.Tamb = Tamb

    def fuel_Departure(self) -> float:
        # Linear fit calculation
        fuel_Departure = math.sqrt(self.Tamb) * (self.plane.a2_Departure + self.plane.b2_Departure*self.time_Departure
                                                  + self.plane.c2_Departure*self.na_Departure) 
        return fuel_Departure

    def fuel_Arrival(self) -> float:
        # Linear fit calculation
        fuel_Arrival = math.sqrt(self.Tamb) * (self.plane.a2_Arrival + self.plane.b2_Arrival*self.time_Arrival
                                                + self.plane.c2_Arrival*self.na_Arrival) 
        return fuel_Arrival

    def ratioTaxiFuel_DesignFuel(self) -> float:
        fuel = self.fuel_Departure() + self.fuel_Arrival() 
        return (fuel/self.plane.design_Fuel)*100
    
A319 = Plane(0.0000, 0.0122, 0.0965, 0.0000, 0.0118, 0.1309, 13020)
A320 = Plane(0.0000, 0.0124, 0.1174, -0.0706, 0.0123, 0.1199, 17940)
A321 = Plane(0.0000, 0.0129, 0.0832, 0.0000, 0.0126, 0.1544, 23330)
ARJ85 = Plane(0.0973, 0.0102, 0.0366, 0.000, 0.0106, 0.0517, 10023)

TaxiA319Toulouse = Taxi(A319, 600, 270, 4, 4, 288)
TaxiA320Toulouse = Taxi(A320, 600, 270, 4, 4, 288)
TaxiA321Toulouse = Taxi(A321, 600, 270, 4, 4, 288)
TaxiARJ85Toulouse = Taxi(ARJ85, 600, 270, 4, 4, 288)

print(TaxiA319Toulouse.fuel_Arrival()+TaxiA319Toulouse.fuel_Departure())
print(TaxiA320Toulouse.fuel_Arrival()+TaxiA319Toulouse.fuel_Departure())
print(TaxiA321Toulouse.fuel_Arrival()+TaxiA319Toulouse.fuel_Departure())
print(TaxiARJ85Toulouse.fuel_Arrival()+TaxiA319Toulouse.fuel_Departure())
print("\n\n")
print(TaxiA319Toulouse.ratioTaxiFuel_DesignFuel())
print(TaxiA320Toulouse.ratioTaxiFuel_DesignFuel())
print(TaxiA321Toulouse.ratioTaxiFuel_DesignFuel())
print(TaxiARJ85Toulouse.ratioTaxiFuel_DesignFuel())

